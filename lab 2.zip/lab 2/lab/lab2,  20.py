#Задана последовательность из N вещественных чисел. Определить,
#сколько среди них чисел меньших К, равных К и больших К. 


def glavnaia():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(*dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Ввод последовательности чисел и числа K"""
    print("Введите последовательность вещественных чисел, разделенных пробелом:")
    poryadok = list(map(float, input().strip().split()))
    print("Введите число K:")
    k = float(input().strip())
    return poryadok, k

def reshenie(poryadok, k):
    """
    Подсчет чисел меньше, равных и больше K.
    Возвращает кортеж (count_less, count_equal, count_greater).
    """
    count_menshe = sum(1 for x in poryadok if x < k)
    count_ravno = sum(1 for x in poryadok if x == k)
    count_bolshe = sum(1 for x in poryadok if x > k)
    return count_menshe, count_ravno, count_bolshe

def vyvod_rezultata(rezultat):
    """Вывод результата подсчета"""
    count_menshe, count_ravno, count_bolshe = rezultat
    print(f"Чисел меньше K: {count_menshe}")
    print(f"Чисел равных K: {count_ravno}")
    print(f"Чисел больше K: {count_bolshe}")

if __name__ == "__main__":
    glavnaia()

