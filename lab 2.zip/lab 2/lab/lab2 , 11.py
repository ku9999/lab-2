#Даны целые числа а1 а2,..., a n. Вывести на печать только те 
#числа, для которых a1 >= i /. 



def glavnaia():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Ввод массива целых чисел"""
    print("Введите массив целых чисел, разделенных пробелом:")
    massyv = list(map(int, input().strip().split()))
    return massyv

def reshenie(massyv):
    """
    Отбор чисел, для которых \( a_i \geq i \).
    Возвращает список таких чисел.
    """
    return [znachenie for i, znachenie in enumerate(massyv, start=1) if znachenie >= i]

def vyvod_rezultata(rezultat):
    """Вывод подходящих чисел"""
    print("Числа, для которых a[i] >= i:")
    print(" ".join(map(str, rezultat)))

if __name__ == "__main__":
    glavnaia()
