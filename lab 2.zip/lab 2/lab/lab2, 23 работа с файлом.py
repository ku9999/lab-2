#Дан текст на русском языке. Напечатать в алфавитном порядке 
#все звонкие согласные буквы, которые входят хотя бы в одно слово. 

def main():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Чтение текста из файла"""
    try:
        with open("dda.txt", "r", encoding="utf-8") as fail:
            tekst = fail.read().strip()
        return tekst
    except FileNotFoundError:
        print("Ошибка: Файл не найден. Проверьте путь и имя файла.")
        exit()

def reshenie(tekst):
    """
    Найти все строчные русские звонкие согласные буквы, которые встречаются хотя бы в одном слове.
    Возвращает отсортированное множество найденных букв.
    """
    zvonkie_soglasnye = {'б', 'в', 'г', 'д', 'ж', 'з', 'й', 'л', 'м', 'н', 'р'}
    naidennye_soglasnye = set()
    
    # Разделяем текст на слова
    slova = tekst.split()
    for slovo in slova:
        # Для каждого слова проверяем наличие звонких согласных
        naidennye_soglasnye.update(bukva for bukva in slovo if bukva in zvonkie_soglasnye)
    
    return sorted(naidennye_soglasnye)

def vyvod_rezultata(rezultat):
    """Вывод звонких согласных букв"""
    if rezultat:
        print("Звонкие согласные буквы, входящие в слова, в алфавитном порядке:")
        print(" ".join(rezultat))
    else:
        print("В тексте не найдено звонких согласных.")

if __name__ == "__main__":
    main()
