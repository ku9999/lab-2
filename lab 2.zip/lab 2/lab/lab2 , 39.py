#Для заданного текста определить длину содержащейся в нем 
#максимальной серии символов, отличных от букв. 

def glavnaia():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Ввод текста"""
    print("Введите текст:")
    tekst = input().strip()
    return tekst

def reshenie(tekst):
    """
    Определяет длину максимальной серии символов, отличных от букв.
    Возвращает длину максимальной серии.
    """
    max_dlinna = 0
    tekushchaya_dlinna = 0
    
    for simvol in tekst:
        if not simvol.isalpha():  # Если символ не буква
            tekushchaya_dlinna += 1
            max_dlinna = max(max_dlinna, tekushchaya_dlinna)
        else:
            tekushchaya_dlinna = 0  # Сбрасываем длину при встрече буквы
    
    return max_dlinna

def vyvod_rezultata(dlinna_maximalnoi_serii):
    """Вывод длины максимальной серии символов, отличных от букв"""
    print(f"Длина максимальной серии символов, отличных от букв: {dlinna_maximalnoi_serii}")

if __name__ == "__main__":
    glavnaia()
