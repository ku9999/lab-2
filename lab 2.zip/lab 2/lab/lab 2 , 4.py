#Дана последовательность действительных чисел а1 а2 ..., аn. 
#Выяснить, будет ли она возрастающей. 



def glavnaia():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Ввод последовательности чисел"""
    print("Введите последовательность действительных чисел, разделенных пробелом:")
    poryadok = list(map(float, input().strip().split()))
    return poryadok

def reshenie(poryadok):
    """
    Проверка, является ли последовательность возрастающей.
    Возвращает True, если последовательность строго возрастает, иначе False.
    """
    return all(poryadok[i] < poryadok[i + 1] for i in range(len(poryadok) - 1))

def vyvod_rezultata(vozrastaiushchaya):
    """Вывод результата проверки"""
    if vozrastaiushchaya:
        print("Последовательность строго возрастающая.")
    else:
        print("Последовательность не является строго возрастающей.")

if __name__ == "__main__":
    glavnaia()
