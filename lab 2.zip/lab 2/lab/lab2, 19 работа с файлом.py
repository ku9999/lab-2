#Дан текст, за которым следует точка. В алфавитном порядке 
#напечатать все строчные русские гласные буквы (а, е, и, о, у, ы, 
#э, ю, я), входящие в этот текст. 


def glavnaia():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Чтение текста из файла"""
    try:
        with open("dda.txt", "r", encoding="utf-8") as fail:
            tekst = fail.read().strip().rstrip('.')
        return tekst
    except FileNotFoundError:
        print("Ошибка: Файл не найден. Проверьте путь и имя файла.")
        exit()

def reshenie(tekst):
    """
    Найти все строчные русские гласные буквы, входящие в текст.
    Возвращает отсортированное множество найденных букв.
    """
    glasnye = {'а', 'е', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я'}
    naidennye_glasnye = {bukva for bukva in tekst if bukva in glasnye}
    return sorted(naidennye_glasnye)

def vyvod_rezultata(rezultat):
    """Вывод гласных букв"""
    print("Гласные буквы в тексте в алфавитном порядке:")
    print(" ".join(rezultat))

if __name__ == "__main__":
    glavnaia()
