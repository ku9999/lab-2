#В записке слова зашифрованы — каждое из них записано 
#наоборот. Расшифровать сообщение. 

def glavnaia():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Ввод зашифрованного сообщения"""
    print("Введите зашифрованное сообщение (слова через пробел):")
    soobshchenie = input().strip()
    return soobshchenie

def reshenie(soobshchenie):
    """
    Расшифровка сообщения, записанного наоборот.
    Возвращает расшифрованное сообщение.
    """
    slova = soobshchenie.split()
    rassyfrovannye_slova = [slovo[::-1] for slovo in slova]
    return " ".join(rassyfrovannye_slova)

def vyvod_rezultata(rassyfrovannoe_soobshchenie):
    """Вывод расшифрованного сообщения"""
    print("Расшифрованное сообщение:")
    print(rassyfrovannoe_soobshchenie)

if __name__ == "__main__":
    glavnaia()

