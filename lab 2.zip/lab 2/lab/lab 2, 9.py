#Дан массив действительных чисел, размерность которого N. 
#Подсчитать, сколько в нем отрицательных, положительных и 
#нулевых элементов. 


def glavnaia():
    """Главная функция программы"""
    dannye = vvod_dannykh()
    rezultat = reshenie(dannye)
    vyvod_rezultata(rezultat)

def vvod_dannykh():
    """Ввод массива чисел"""
    print("Введите массив действительных чисел, разделенных пробелом:")
    massyv = list(map(float, input().strip().split()))
    return massyv

def reshenie(massyv):
    """
    Подсчет количества отрицательных, положительных и нулевых элементов.
    Возвращает кортеж (count_negative, count_positive, count_zeros).
    """
    count_negative = sum(1 for x in massyv if x < 0)
    count_positive = sum(1 for x in massyv if x > 0)
    count_zeros = sum(1 for x in massyv if x == 0)
    return count_negative, count_positive, count_zeros

def vyvod_rezultata(rezultat):
    """Вывод результата подсчета"""
    count_negative, count_positive, count_zeros = rezultat
    print(f"Отрицательных элементов: {count_negative}")
    print(f"Положительных элементов: {count_positive}")
    print(f"Нулевых элементов: {count_zeros}")

if __name__ == "__main__":
    glavnaia()

